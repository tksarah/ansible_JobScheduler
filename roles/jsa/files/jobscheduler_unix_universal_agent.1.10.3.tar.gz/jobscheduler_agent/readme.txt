
                                             Software- und
                                             Organisations-
                                             Service GmbH

                                             Giesebrechtstr. 15
                                             D-10629 Berlin
                                             tel  +49 (30) 86 47 90-0
                                             fax  +49 (30) 8 61 33 35
                                             mail info@sos-berlin.com
                                             web   www.sos-berlin.com


JobScheduler Universal Agent
============================

Use the following links for information about
* Platforms:                         https://kb.sos-berlin.com/x/cgiX
* Architecture:                      https://kb.sos-berlin.com/x/MQCs
* Installation and Operation:        https://kb.sos-berlin.com/x/kQiX